from .api import AiCaptcha

__version__ = '1.0.3'
